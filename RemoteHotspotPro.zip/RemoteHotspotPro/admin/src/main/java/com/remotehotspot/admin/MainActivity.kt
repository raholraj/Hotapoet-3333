package com.remotehotspot.admin

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.remotehotspot.shared.*
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val vm: AdminViewModel by viewModels()

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            val dark = isSystemInDarkTheme()
            val scheme = if (dark) darkColorScheme(primary = Color(0xFF4DD0E1), secondary = Color(0xFF80CBC4))
            else lightColorScheme(primary = Color(0xFF00796B), secondary = Color(0xFF1565C0))
            MaterialTheme(colorScheme = scheme) { AdminScreen(vm) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminScreen(vm: AdminViewModel) {
    val ctx = LocalContext.current
    val devices by vm.devices.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    var showLogs by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.toast.collect { snack.showSnackbar(it) } }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(title = { Text("Hotspot Admin") }, actions = {
                IconButton({ vm.refresh() }) { Icon(Icons.Filled.Refresh, "Refresh") }
                IconButton({ showLogs = true }) { Icon(Icons.Filled.History, "Logs") }
            })
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (devices.isNotEmpty()) Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ vm.bulk(Cmd.HOTSPOT_ON) }, Modifier.weight(1f)) { Text("All ON") }
                OutlinedButton({ vm.bulk(Cmd.HOTSPOT_OFF) }, Modifier.weight(1f)) { Text("All OFF") }
            }
            when {
                loading && devices.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                devices.isEmpty() -> EmptyState()
                else -> LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(devices, key = { it.deviceId }) { d -> DeviceCard(d, d.deviceId in busy) { vm.command(d, it) } }
                }
            }
        }
    }

    if (showLogs) AlertDialog(onDismissRequest = { showLogs = false }, title = { Text("Connection log") },
        text = { LazyColumn(Modifier.heightIn(max = 380.dp)) { if (logs.isEmpty()) item { Text("No events yet") }; items(logs) { Text(it, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) } } },
        confirmButton = { TextButton({
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, vm.exportLogs()), "Export logs")) }) { Text("Export") } },
        dismissButton = { TextButton({ showLogs = false }) { Text("Close") } })
}

@Composable
private fun EmptyState() = Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
    Icon(Icons.Filled.WifiTethering, null, Modifier.size(96.dp), tint = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(16.dp))
    Text("Install User app and turn on Accessibility. Devices appear here automatically.", textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium)
}

@Composable
private fun DeviceCard(d: DeviceInfo, busy: Boolean, onCmd: (String) -> Unit) {
    val time = DateFormat.getTimeInstance()
    Card(Modifier.fillMaxWidth().animateContentSize(), elevation = CardDefaults.cardElevation(4.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).background(Color(0xFF00897B), CircleShape)); Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.name, style = MaterialTheme.typography.titleMedium)
                    Text("${d.manufacturer} ${d.model}", style = MaterialTheme.typography.bodySmall)
                }
                Text("Online", color = Color(0xFF00897B), style = MaterialTheme.typography.labelLarge)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip({}, { Text("Hotspot: " + when (d.hotspot) { true -> "ON"; false -> "OFF"; null -> "?" }) })
                AssistChip({}, { Text("Battery: ${if (d.battery >= 0) "${d.battery}%" else "?"}${if (d.charging) " ⚡" else ""}") })
            }
            Text("Last seen: ${if (d.lastSeen > 0) time.format(Date(d.lastSeen)) else "never"}", style = MaterialTheme.typography.bodySmall)
            if (d.lastCmd.isNotEmpty()) Text("Last command: ${d.lastCmd} at ${time.format(Date(d.lastCmdTs))}", style = MaterialTheme.typography.bodySmall)
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ onCmd(Cmd.HOTSPOT_ON) }, Modifier.weight(1f), enabled = !busy) { Text("ON") }
                OutlinedButton({ onCmd(Cmd.HOTSPOT_OFF) }, Modifier.weight(1f), enabled = !busy) { Text("OFF") }
                FilledTonalButton({ onCmd(Cmd.TOGGLE) }, Modifier.weight(1f), enabled = !busy) { Text("Toggle") }
            }
        }
    }
}
