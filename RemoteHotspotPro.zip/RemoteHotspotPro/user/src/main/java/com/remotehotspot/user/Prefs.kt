package com.remotehotspot.user

import android.content.Context
import java.util.UUID

/** Tiny wrapper over SharedPreferences. Device ID is generated once and never changes. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("rh_user", Context.MODE_PRIVATE)
    val deviceId: String get() = sp.getString("deviceId", null) ?: UUID.randomUUID().toString().also { sp.edit().putString("deviceId", it).apply() }
    val token: String get() = sp.getString("token", null) ?: UUID.randomUUID().toString().replace("-", "").also { sp.edit().putString("token", it).apply() }
    var tileX: Int get() = sp.getInt("tileX", -1); set(v) = sp.edit().putInt("tileX", v).apply()
    var tileY: Int get() = sp.getInt("tileY", -1); set(v) = sp.edit().putInt("tileY", v).apply()
}
