package com.remotehotspot.user

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Toggles the hotspot by driving the Quick Settings panel. Layers (in order):
 *  1. node tree text / content-description match
 *  2. view-id match
 *  3. saved coordinates (auto-learned from the last successful tile click)
 *  4. open system tethering settings (manual last resort)
 * Every layer is followed by a state verification (reflection state, then tile checked-state).
 */
class HotspotAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "HotspotA11y"
        @Volatile var instance: HotspotAccessibilityService? = null
        val logBuffer = ArrayDeque<String>()
        fun log(m: String) { Log.d(TAG, m); synchronized(logBuffer) { logBuffer.addLast("${System.currentTimeMillis()} $m"); if (logBuffer.size > 300) logBuffer.removeFirst() } }

        /** Texts that identify the hotspot tile across Realme / Samsung / Infinix / AOSP. */
        val LABELS = listOf("mobile hotspot", "personal hotspot", "wi-fi hotspot", "wifi hotspot", "portable hotspot",
            "portable wi-fi hotspot", "hotspot", "tethering", "wlan hotspot", "mobile ap")
        val ID_HINTS = listOf("hotspot", "tether", "wifi_ap", "softap")

        /** Reads hotspot state via the hidden WifiManager API (works on most OEM builds); null if unavailable. */
        fun isHotspotOn(ctx: Context): Boolean? = runCatching {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val m = WifiManager::class.java.getDeclaredMethod("isWifiApEnabled"); m.isAccessible = true
            m.invoke(wm) as Boolean
        }.getOrElse {
            runCatching {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val m = WifiManager::class.java.getDeclaredMethod("getWifiApState"); m.isAccessible = true
                (m.invoke(wm) as Int) % 10 == 3 // 13 = ENABLED, 11 = DISABLED
            }.getOrNull()
        }
    }

    private val mutex = Mutex()
    override fun onServiceConnected() { instance = this; log("connected"); CoreService.start(this) }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    data class Result(val ok: Boolean, val msg: String, val state: Boolean?)

    /** target: true=ON, false=OFF, null=toggle. */
    suspend fun setHotspot(target: Boolean?): Result = mutex.withLock {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!pm.isInteractive) return Result(false, "Screen is OFF", isHotspotOn(this))
        if (km.isKeyguardLocked) return Result(false, "Screen is locked", isHotspotOn(this))

        val before = isHotspotOn(this)
        val want = target ?: before?.not()
        if (want != null && before == want) return Result(true, "Already ${if (want) "ON" else "OFF"}", before)

        for (attempt in 0 until 3) {
            log("attempt ${attempt + 1}, want=$want, before=$before")
            performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            delay(900L + attempt * 600L)

            var tile = findTile(rootInActiveWindow)
            if (tile == null) { swipeDownToExpand(); delay(700); tile = findTile(rootInActiveWindow) }

            val prefs = Prefs(this)
            var clicked = false
            if (tile != null) {
                val r = Rect(); tile.getBoundsInScreen(r)
                clicked = clickNode(tile)
                if (clicked) { prefs.tileX = r.centerX(); prefs.tileY = r.centerY(); log("layer1/2 click @${r.centerX()},${r.centerY()}") }
            }
            if (!clicked && prefs.tileX > 0) { clicked = tap(prefs.tileX, prefs.tileY); log("layer3 coordinate tap=$clicked") }

            if (clicked) {
                val st = verify(want, tile)
                closePanel()
                if (st.first) return Result(true, "Hotspot ${if (st.second == true) "ON" else "OFF"}", st.second)
                log("verify failed: ${st.second}")
            } else closePanel()
            delay(backoff(attempt))
        }
        // layer 4: manual last resort
        runCatching {
            startActivity(Intent("com.android.settings.TetherSettings").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        Result(false, "Could not toggle automatically; opened hotspot settings", isHotspotOn(this))
    }

    private fun backoff(a: Int) = 800L shl a

    private suspend fun verify(want: Boolean?, tile: AccessibilityNodeInfo?): Pair<Boolean, Boolean?> {
        repeat(6) {
            delay(700)
            val s = isHotspotOn(this) ?: tile?.let { runCatching { it.refresh(); tileState(it) }.getOrNull() }
            if (s != null && (want == null || s == want)) return true to s
            if (s == null) return true to null // cannot verify on this device: trust the click
        }
        return false to isHotspotOn(this)
    }

    private fun tileState(n: AccessibilityNodeInfo): Boolean? {
        if (n.isCheckable) return n.isChecked
        val d = (if (Build.VERSION.SDK_INT >= 30) n.stateDescription?.toString() else null)?.lowercase()
            ?: n.contentDescription?.toString()?.lowercase() ?: return null
        return when { "off" in d -> false; "on" in d -> true; else -> null }
    }

    // ---------- tile search ----------
    private fun findTile(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        root ?: return null
        val all = ArrayList<AccessibilityNodeInfo>(); collect(root, all)
        // layer 1: text / content description
        for (label in LABELS) all.firstOrNull { n ->
            (n.text?.toString()?.lowercase()?.contains(label) == true || n.contentDescription?.toString()?.lowercase()?.contains(label) == true)
        }?.let { return it }
        // layer 2: resource-id
        return all.firstOrNull { n -> n.viewIdResourceName?.lowercase()?.let { id -> ID_HINTS.any { it in id } } == true }
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        n ?: return; if (depth > 30) return
        out.add(n); for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    private suspend fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n; var hops = 0
        while (c != null && hops < 6) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent; hops++
        }
        val r = Rect(); n.getBoundsInScreen(r); return r.width() > 0 && tap(r.centerX(), r.centerY())
    }

    // ---------- gestures ----------
    private suspend fun tap(x: Int, y: Int): Boolean = dispatch(Path().apply { moveTo(x.toFloat(), y.toFloat()) }, 60)

    private suspend fun swipeDownToExpand() {
        val m = resources.displayMetrics
        dispatch(Path().apply { moveTo(m.widthPixels / 2f, 40f); lineTo(m.widthPixels / 2f, m.heightPixels * 0.6f) }, 300)
    }

    private suspend fun dispatch(p: Path, dur: Long): Boolean {
        var done = false; var ok = false
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; done = true }
            override fun onCancelled(d: GestureDescription?) { done = true }
        }, null)
        var waited = 0; while (!done && waited < 2000) { delay(50); waited += 50 }
        return ok
    }

    private suspend fun closePanel() { performGlobalAction(GLOBAL_ACTION_BACK); delay(250); performGlobalAction(GLOBAL_ACTION_BACK) }
}
