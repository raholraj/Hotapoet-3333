package com.remotehotspot.user

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Auto-start the service after boot / app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { CoreService.start(c) }
}
