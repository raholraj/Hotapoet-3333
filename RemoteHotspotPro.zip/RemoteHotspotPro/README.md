# Remote Hotspot Pro (auto-discovery, no pairing)

- `user/`  : enable Accessibility -> phone registers itself at /devices/{id}, heartbeat every 30 s, executes HOTSPOT_ON / HOTSPOT_OFF / TOGGLE.
- `admin/` : lists every device with recent lastSeen (<90 s), buttons ON / OFF / Toggle, bulk All ON / All OFF.
- `shared/`: models + FirebaseRepo.   `firebase/`: database.rules.json

## One-time Firebase setup
1. Authentication > Sign-in method > Anonymous > Enable.
2. Realtime Database > Rules > paste firebase/database.rules.json > Publish.
3. Realtime Database > Data: add node `config` with child `adminKey` = your secret (letters/numbers only, e.g. Rh7kQ92xLm4Z).
4. GitHub repo secret `ADMIN_KEY` = the same value. (Plus ADMIN_GOOGLE_SERVICES, USER_GOOGLE_SERVICES.)
Why: without pairing, the key is the only thing stopping a stranger's Admin build from controlling your devices.
Only APKs built with the right key can read devices or send commands.

## Notes
- Bluetooth, FCM and pairing were removed. Commands travel over Firebase only.
- Hotspot toggle needs screen ON + unlocked on the User phone.
- Anyone who has the Admin APK can extract the key: share it only with people you trust.
